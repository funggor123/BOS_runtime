#!/bin/bash
c_user="$USER"
start_path="$PWD"
echo "Hey, it is going to install bos now"
echo "Are you ready?(y/n)"
read choice
if [ "$choice" = "n" ] ; then
        echo "The installation has been terminated"
        exit 0
fi
echo "OK, lets get start"

echo "Please provide the host port of this bos node (Default: 8081): "
read host_port
if [ -z "$host_port" ] ;
then host_port="8081"
fi

echo "-----------------Installing MongoDB--------"
if which mongod >/dev/null; then
       echo "Mongodb is detected, no need to install "
else
       echo "Mongodb is not detected, is going to install now"
       apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv 9DA31620334BD75D9DCB49F368818C72E52529D4
       echo "deb [ arch=amd64 ] https://repo.mongodb.org/apt/ubuntu trusty/mongodb-org/4.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-4.0.list
       apt-get update
       apt-get install -y mongodb-org
       service mongod start
fi

echo "Dropping the database"
mongo bos_v2 --eval "db.dropDatabase()"

cat <<EOF > conf.json
{
    "port" : "$host_port",
    "log_file_path" : "./log/",
    "mongodb_url" : "localhost:27017",
    "mongodb_db_name" : "bos_v2",
    "download_dir" : "./download",
    "upload_dir" : "./upload",
    "dencrypt_dir" : "./decrypted",
    "encrypt_dir" : "./encrypted",
    "signed_dir" : "./signed",
    "verify_dir" : "./verified",
    "upload_msg_dir" : "./uploadmsg",
    "download_msg_dir" : "./dnloadmsg",
    "afs_download_url" : "http://139.159.244.231:8098/file/download",
    "afs_upload_url" : "http://139.159.244.231:8098/file/upload"
}
EOF
echo "Congratulation !! The installation has completed"
