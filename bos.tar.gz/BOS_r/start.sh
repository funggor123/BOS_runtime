nohup ./main &
